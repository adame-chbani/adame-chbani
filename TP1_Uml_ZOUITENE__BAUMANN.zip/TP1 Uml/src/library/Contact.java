package library;

public class Contact {
    private String firstName;
    private String lastName;
    private String middleName;
    private String email;
    private String locale;
    
    public Contact(String firstName, String lastName, String middleName, String email) {
    	this.firstName = firstName;
    	this.lastName = lastName;
    	this.middleName = middleName;
    	this.email = email;
    	this.locale = "English";
    }
}
