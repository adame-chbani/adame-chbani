package library;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import library.utils.CustomerType;
import library.utils.Rehost;
import library.utils.EntitlementType;
import library.utils.LockingType;

public class Main {
   @SuppressWarnings("deprecation")
public static void main(String[] args){
	   BatchCode a = new BatchCode("23456789");
	   BatchCode b = new BatchCode("12345678");
	   BatchCode c = new BatchCode("12345679");
	   BatchCode d = new BatchCode("23456781");
	   BatchCode e = new BatchCode("12356789");
	   BatchCode f = new BatchCode("09876543");
	   BatchCode g = new BatchCode("23456718");
	   BatchCode h = new BatchCode("12365431");
	   
	   Customer Juste = new Customer(000, CustomerType.Individual, "Il est gentil", a);
	   Customer Huma = new Customer(001, CustomerType.Company, "Grande entreprise", b);
	   
    
   	   Details shipping = new Details("rue principale", "Dom�liers", "60360", "France");
   	   Details billing1 = new Details("all�e du sapin bleu", "Villejuif", "94800", "France");
   	   Details billing2 = new Details("Route du Conn�table", "Chantilly", "60500", "France");
   	   
   	   Entitlement biggestclient = new Entitlement("01", EntitlementType.a, new Date(2021, 2, 1), new Date(2021, 2, 31),  "Le meilleur client du mois de mars !",  Huma);
   	   
   	   Contact C000 = new Contact("Xavier", "Dubois", "", "xavier.dubois@huma.com");
   	   
   	   Company E000 = new Company("Huma", "0344811991", "+41217211111", billing2, shipping, C000, Huma);
   	   
   	   Individual I000 = new Individual("Juste", "Leblanc", "", "justeleblanc@gmail.com", "0355446655", Juste, billing1, shipping);
   	   
   	   Product volant = new Product(0000, "volant de kangoo", LockingType.HL, Rehost.Enable, 
   			   "Peut tourner vers la droite & la gauche", c);
   	   Product roue = new Product(0001, "roue de kangoo", LockingType.HL, Rehost.Enable, "Tient bein la route", d);
   	   
   	   List<Product> voiture = new ArrayList<Product>();
   	   voiture.add(volant);
   	   voiture.add(roue);
   	   
   	   Product kangoo = new Product(0002, "Kangoo", LockingType.HL, Rehost.Enable, "Une voiture toute neuve", e, voiture );
   	   
   	   Feature v�hicule = new Feature(00000, "v�hicule", "Fonctionel", f);
   	   Feature pneu = new Feature(00001, "pneu", "D�j� sur la roue", g);
   	   Feature toitouvrant = new Feature(00002, "toit ouvrant", "aucun v�hicule de ce type", h);
   	   
   	   List<Feature> lf1 = new ArrayList<Feature>();
   	   lf1.add(pneu);
   	   List<Feature> lf2 = new ArrayList<Feature>();
   	   lf2.add(v�hicule);
   	   lf2.add(toitouvrant);
   	   
   	   kangoo.setFeatures(lf2);
   	   roue.setFeatures(lf1);
   	   
   	   
   	   
	}
}
