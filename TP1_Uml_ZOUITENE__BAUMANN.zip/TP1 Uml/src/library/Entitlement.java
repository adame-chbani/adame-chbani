package library;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import library.utils.EntitlementType;

class Entitlement {
	private String EID;
	private EntitlementType type;
	private Date startDate;
	private Date endDate;
	private Boolean neverExpires;
	private String comments;
	
	private Customer customer;
	private List<Product> products;
	
	public Entitlement(String EID, EntitlementType type, Date startDate, Date endDate, String comments, Customer customer) {
		this.EID = EID;
		this.startDate = startDate;
		this.endDate = endDate;
		this.neverExpires = true;
		this.comments = comments;
		this.customer = customer;
		this.products = new ArrayList<Product>();
		this.type = type;
	}
	
}
