package library;

import java.util.ArrayList;
import java.util.List;

public class BatchCode {
    private String id;
    
    private List<Feature> features;
    private Customer customer;
    private List<Product> products;
    
    public BatchCode(String id) {
    	this.id = id;
    	this.features = new ArrayList<Feature>();
    	this.products = new ArrayList<Product>();
    }
}
