package library.utils;

public enum CustomerType {
	Individual,
	Company
	
}
