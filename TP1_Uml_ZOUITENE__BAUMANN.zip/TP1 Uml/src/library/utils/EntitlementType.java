package library.utils;

public enum EntitlementType {
	a,
	b
}
