package library;

import library.utils.CustomerType;

public class Individual extends Customer{
	private String firstName;
	private String lastName;
	private String middleName;
	private String email;
	private String phone;
	private String locale;
	
	private Details billing;
	private Details shipping;
	
	public Individual(String firstName, String lastName, String middleName, String email, String phone, 
			Details billing, Details shipping, int CRM_ID, CustomerType type, String description, BatchCode code) {
		super(CRM_ID,type,description,code);
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.email = email;
		this.phone = phone;
		this.locale = "English";
		this.billing = billing;
		this.shipping = shipping;
	}
	
	public Individual(String firstName, String lastName, String middleName, String email, String phone, Customer customer,
			Details billing, Details shipping) {
		super(customer);
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.email = email;
		this.phone = phone;
		this.locale = "English";
		this.billing = billing;
		this.shipping = shipping;
	}
}
