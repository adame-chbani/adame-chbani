package library;

import library.utils.CustomerType;

public class Company extends Customer{
    private String name;
    private String phone;
    private String fax;
    
    private Details billing;
    private Details shipping;
    private Contact contact;
    
    public Company(String name, String phone, String fax, Details billing, Details shipping, Contact contact,
    		int CRM_ID, CustomerType type, String description, BatchCode code) {
    	super(CRM_ID,type,description,code);
    	this.name = name;
    	this.phone = phone;
    	this.fax = fax;
    	this.billing = billing;
    	this.shipping = shipping;
    	this.contact = contact;
    }
    
    public Company(String name, String phone, String fax, Details billing, Details shipping, Contact contact, Customer customer) {
    	super(customer);
    	this.name = name;
    	this.phone = phone;
    	this.fax = fax;
    	this.billing = billing;
    	this.shipping = shipping;
    	this.contact = contact;
    }
}
