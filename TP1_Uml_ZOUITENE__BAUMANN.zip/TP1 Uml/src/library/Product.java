package library;

import java.util.List;
import java.util.ArrayList;
import library.utils.LockingType;
import library.utils.Rehost;

public class Product {
	private int id;
	private String name;
	private LockingType lockingtype;
	private Rehost rehost;
	private String description;
	private Boolean provisional;
	private BatchCode code;
	private List<Product> baseproduct;
	private List<Feature> features;
	
	public Product(int id, String name, LockingType lockingtype, Rehost rehost, String description, BatchCode code) {
		this.id = id;
		this.name = name;
		this.lockingtype = lockingtype;
		this.rehost = rehost;
		this.description = description;
		this.code = code;
		this.baseproduct = new ArrayList<Product>();
		this.features = new ArrayList<Feature>();
	}
	
	public Product(int id, String name, LockingType lockingtype, Rehost rehost, String description, BatchCode code, List<Product> baseproduct) {
		this.id = id;
		this.name = name;
		this.lockingtype = lockingtype;
		this.rehost = rehost;
		this.description = description;
		this.code = code;
		this.baseproduct = baseproduct;
		this.features = new ArrayList<Feature>();
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public LockingType getLockingtype() {
		return lockingtype;
	}

	public Rehost getRehost() {
		return rehost;
	}

	public String getDescription() {
		return description;
	}

	public Boolean getProvisional() {
		return provisional;
	}

	public BatchCode getCode() {
		return code;
	}

	public List<Product> getBaseproduct() {
		return baseproduct;
	}

	public List<Feature> getFeatures() {
		return features;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setLockingtype(LockingType lockingtype) {
		this.lockingtype = lockingtype;
	}

	public void setRehost(Rehost rehost) {
		this.rehost = rehost;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setProvisional(Boolean provisional) {
		this.provisional = provisional;
	}

	public void setCode(BatchCode code) {
		this.code = code;
	}

	public void setBaseproduct(List<Product> baseproduct) {
		this.baseproduct = baseproduct;
	}

	public void setFeatures(List<Feature> features) {
		this.features = features;
	}
}
