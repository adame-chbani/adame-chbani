package library;

public class Feature {
	private int id;
	private String name;
	private String description;
	
	private BatchCode code;
	
	public Feature(int id, String name, String description, BatchCode code) {
		this.id = id;
		this.name = name; 
		this.description = description;
		this.code = code;
	}
}
