package library;

import java.util.ArrayList;
import java.util.List;

import library.utils.CustomerType;

public class Customer {
	private int CRM_ID;
	private CustomerType type;
	private String description;
	
	private List<Entitlement> entitlements;
	private BatchCode code;
	
	public Customer(int CRM_ID, CustomerType type, String description, BatchCode code) {
		this.CRM_ID = CRM_ID;
		this.type = type;
		this.description = description;
		this.entitlements = new ArrayList<Entitlement>();
		this.code = code;
		
	}
	public Customer(Customer customer) {
		this.CRM_ID = customer.CRM_ID;
		this.type = customer.type;
		this.description = customer.description;
		this.entitlements = customer.entitlements;
		this.code = customer.code;
	}
}
